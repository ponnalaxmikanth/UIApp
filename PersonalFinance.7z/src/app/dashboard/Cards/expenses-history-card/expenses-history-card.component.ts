import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expenses-history-card',
  templateUrl: './expenses-history-card.component.html',
  styleUrls: ['./expenses-history-card.component.scss']
})
export class ExpensesHistoryCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
